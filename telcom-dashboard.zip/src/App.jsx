import TrainingExercise from './components/TrainingExercise';
export default function App() {
  return <TrainingExercise />;
}
